var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["5fc6a6a8-767a-4bf4-a88e-40bffeaeb0ef"],"propsByKey":{"5fc6a6a8-767a-4bf4-a88e-40bffeaeb0ef":{"name":"ball1","sourceUrl":null,"frameSize":{"x":397,"y":187},"frameCount":1,"looping":true,"frameDelay":12,"version":"ykFbSjvBQxW3qxWhU5Ld__cQWjS8WbjD","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":397,"y":187},"rootRelativePath":"assets/5fc6a6a8-767a-4bf4-a88e-40bffeaeb0ef.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var ball = createSprite(200, 200, 15, 15);
ball.shapeColor = "green";
var cp = createSprite(10, 200, 10, 50);
cp.shapeColor = "red";
var pp = createSprite(390, 200, 10, 50);
pp.shapeColor = "red";
var net = createSprite(200, 200, 1, 400);
function draw() {
  background("black");
  if (keyDown("up")) {
    pp.y = pp.y - 10;
  }
  if (keyDown("down")) {
    pp.y = pp.y + 10;
  }
  if (keyDown("space")) {
    ball.velocityX = "5";
    ball.velocityY = "0";
  }
  cp.y = ball.y;
  createEdgeSprites();
  ball.bounceOff(topEdge);
  ball.bounceOff(bottomEdge);
  ball.bounceOff(pp);
  ball.bounceOff(cp);
  drawSprites();
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
